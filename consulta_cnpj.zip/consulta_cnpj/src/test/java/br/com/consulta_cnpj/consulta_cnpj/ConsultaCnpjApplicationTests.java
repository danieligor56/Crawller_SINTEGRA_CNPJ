package br.com.consulta_cnpj.consulta_cnpj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultaCnpjApplicationTests {

	@Test
	void contextLoads() {
	}

}
