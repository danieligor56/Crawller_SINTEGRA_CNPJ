package br.com.consulta_cnpj.consulta_cnpj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsultaCnpjApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsultaCnpjApplication.class, args);
	}

}
